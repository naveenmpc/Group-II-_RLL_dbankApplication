package tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.SignInPage;
import pages.TestBase;
import pages.Withdraw_from_Account_Page;

public class Withdraw_from_Account_Test extends TestBase {

	Withdraw_from_Account_Page wd;
	SignInPage sip;
	
	@BeforeMethod
	public void setup()
	{
		sip=new SignInPage(driver);
		wd=new Withdraw_from_Account_Page(driver);
		sip.enterSignInDetails();
	}
	
	Logger logger = LogManager.getLogger(this);
	@Test()
	public void testwithdraw() throws InterruptedException
	{
		wd.clickonWithDraw();
		
		//Validating Reset button
		wd.enterWithdrawDetails("Individual Checking (Standard Checking)", "20");
		Thread.sleep(3000);
		wd.clickonReset();
		Thread.sleep(3000);
		Assert.assertTrue(wd.validate_Reset_Btn(), "Assert failed- Reset button not working");
		
		//Validating Submit button with empty fields
		wd.clickonSubmit();
		Thread.sleep(3000);
		/*Alert alert = driver.switchTo().alert();
		String actual_alert_txt=alert.getText();
		System.out.println(actual_alert_txt);
		String expected_alert_txt = "Please select an item in the list";
		Assert.assertEquals(actual_alert_txt, expected_alert_txt);
		*/
		Assert.assertTrue(wd.validate_dropdown(), "Assert failed- Reading empty fields");
		
		//Validating Submit button with amount field as 0
		wd.enterWithdrawDetails("Individual Checking (Standard Checking)", "0");
		wd.clickonSubmit();
		Assert.assertTrue(wd.validate_error(), "Assert failed- Accepting amount as 0");
		System.out.println(wd.captureError());
		logger.error(wd.captureError());
		
		//Validating Successful Transaction
		wd.enterWithdrawDetails("Individual Checking (Standard Checking)", "20");
		try {
		wd.clickonSubmit();
		}
		catch(Exception e)
		{
		Assert.assertFalse(wd.validate_dropdown(),"Assert failed- Unsuccessful Transaction");
		}
	}
	
	@AfterMethod
	public void logout()
	{
		sip.logout();
	}
	
}
